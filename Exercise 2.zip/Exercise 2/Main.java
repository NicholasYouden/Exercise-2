public class Main {
  public static void main(String[] args) {
    // Create three circle objects
    Circle c1 = new Circle();
    Circle c2 = new Circle(5);
    Circle c3 = new Circle(3, "Blue");

    // Interact with the methods
    System.out.println(c1.toString());
    System.out.println("Area: " + c1.getArea());

    System.out.println(c2.toString());
    System.out.println("Area: " + c2.getArea());

    System.out.println(c3.toString());
    System.out.println("Area: " + c3.getArea());
  }
}
