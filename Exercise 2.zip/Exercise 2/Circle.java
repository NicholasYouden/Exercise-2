class Circle {
  private int radius;
  private String color;

  // Default constructor
  public Circle() {
    this.radius = 2;
    this.color = "Green";
  }

  // Overloaded constructor for radius
  public Circle(int radius) {
    this.radius = radius;
    this.color = "Green";
  }

  // Overloaded constructor for radius and color
  public Circle(int radius, String color) {
    this.radius = radius;
    this.color = color;
  }

  // Getter for radius
  public int getRadius() {
    return this.radius;
  }

  // Getter for color
  public String getColor() {
    return this.color;
  }

  // Method to calculate area
  public double getArea() {
    return Math.PI * Math.pow(this.radius, 2);
  }

  // Method to return description of circle
  public String toString() {
    return "Radius = " + this.radius + ", Color = " + this.color;
  }
}
